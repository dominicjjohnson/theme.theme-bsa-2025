<?php

	// setup relative urls!