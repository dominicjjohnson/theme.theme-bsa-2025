<?php

	// disable pingbacks and trackbacks