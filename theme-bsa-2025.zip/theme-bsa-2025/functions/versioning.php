<?php

	// disable versioning for scripts and styles etc.