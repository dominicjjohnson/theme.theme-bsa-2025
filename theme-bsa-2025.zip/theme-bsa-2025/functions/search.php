<?php

	// search form location

	// url rewrite for search terms