<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

// if(class_exists('RGForms'))
// 	echo RGForms::parse_shortcode($atts);

echo miramedia_sc_iframes($atts);