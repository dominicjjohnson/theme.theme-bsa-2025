<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Heading', 'fw'),
	'description'   => __('Add a custom heading to the page', 'fw'),
	'tab'           => __('Content Elements', 'fw'),
	'popup_size'    => 'medium'
);