<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

echo '<span class="'.$atts['heading_style'].'"><span style="'.$type_settings_combined.'">'.$atts['text'].'</span></span>';

