<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Speakers', 'fw'),
	'description'   => __('Display hardcoded block of speakers', 'fw'),
	'tab'           => __('Event Elements', 'fw'),
	'popup_size'    => 'small'
);