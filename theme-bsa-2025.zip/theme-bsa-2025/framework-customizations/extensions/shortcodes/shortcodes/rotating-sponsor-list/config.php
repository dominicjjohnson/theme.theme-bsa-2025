<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Sponsor List (Rotating)', 'fw'),
	'description'   => __('Add a list of sponsors to the page', 'fw'),
	'tab'           => __('Content Elements', 'fw'),
	'popup_size'    => 'medium'
);