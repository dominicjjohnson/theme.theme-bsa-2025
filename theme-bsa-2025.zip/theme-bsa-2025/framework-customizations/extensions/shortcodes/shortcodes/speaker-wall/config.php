<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Speaker Wall', 'fw'),
	'description'   => __('Display dynamic list of speakers', 'fw'),
	'tab'           => __('Event Elements', 'fw'),
	'popup_size'    => 'small'
);