<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'id' => array(
	    'type'  => 'text',
	    'label' => __('Slider ID', 'fw'),
	    'desc'  => __('Add in the ID of the slider you want to display.', 'fw'),
	),
);
