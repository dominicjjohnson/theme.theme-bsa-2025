<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('SlideDeck2 Slider', 'fw'),
	'description'   => __('', 'fw'),
	'tab'           => __('Content Elements', 'fw'),
	'popup_size'    => 'small'
);