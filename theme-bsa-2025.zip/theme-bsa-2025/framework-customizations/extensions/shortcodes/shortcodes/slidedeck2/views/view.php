<?php 
	
	if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
	
	echo do_shortcode('[SlideDeck2 id="'.$atts['id'].'" ress="1"]');