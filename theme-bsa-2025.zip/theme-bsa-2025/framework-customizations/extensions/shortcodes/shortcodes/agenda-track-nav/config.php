<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Agenda Nav', 'fw'),
	'description'   => __('Display hardcoded navigation for agendas', 'fw'),
	'tab'           => __('Event Elements', 'fw'),
	'popup_size'    => 'small'
);