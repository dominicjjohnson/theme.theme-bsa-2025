<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Companies', 'fw'),
	'description'   => __('Display hardcoded block of companies', 'fw'),
	'tab'           => __('Event Elements', 'fw'),
	'popup_size'    => 'small'
);