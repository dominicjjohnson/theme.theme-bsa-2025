<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Exhibitor List', 'fw'),
	'description'   => __('The Affordable Weddings Exhibitor List', 'fw'),
	'tab'           => __('Event Elements', 'fw'),
	'popup_size'    => 'small'
);