<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} ?>
<?php echo '<div class="textblock">' . do_shortcode( $atts['text'] ) . '</div>'; ?>
