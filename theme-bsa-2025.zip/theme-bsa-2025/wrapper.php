<?php get_template_part('templates/head'); ?>

<?php get_template_part('templates/header'); ?>

	<?php //get_template_part('templates/nav'); ?>

	<?php include mm_template_path(); ?>

<?php get_template_part('templates/footer'); ?>

<?php get_template_part('templates/foot'); ?>