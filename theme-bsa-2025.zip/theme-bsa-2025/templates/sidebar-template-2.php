<aside class="sidebar">
	<?php 
		if( is_active_sidebar('sidebar_area_2') ) : 
			dynamic_sidebar('sidebar_area_2');
		endif;
	?>	
</aside>