<aside class="sidebar">
	<?php
		if( is_active_sidebar('sidebar_area_3') ) : 
			dynamic_sidebar('sidebar_area_3');
		endif;
	?>
</aside>