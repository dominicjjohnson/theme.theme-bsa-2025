		<noscript>
			<style>
				.no-js { background-image:none; }
				.no-js body { visibility:visible; }
			</style>
		</noscript>

		<?php wp_footer(); ?>

	</div>

</body>
</html>