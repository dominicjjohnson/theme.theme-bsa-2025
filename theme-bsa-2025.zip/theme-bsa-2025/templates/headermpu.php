<?php get_template_part('content/ticker/ticker'); ?>


<div class="top_bar">
	<div id="header-mpu-cycle">
	    <div>
	        <a href="/exhibitor/friedheim-international/" alt="Friedheim International exhibiting at Sign UK"><img src="<?php echo get_stylesheet_directory_uri().'/assets/img/friedmein-600.jpg' ?>" alt=""/></a>
	    </div>
	    <div>
	        <a href="http://www.grafityp.co.uk/" alt="" target="_blank"><img src="<?php echo get_stylesheet_directory_uri().'/assets/img/grafityp-banner.gif' ?>" alt=""/></a>
	    </div>
	</div>
</div>