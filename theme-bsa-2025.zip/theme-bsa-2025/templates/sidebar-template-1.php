<aside class="sidebar">
	<?php 
		if( is_active_sidebar('sidebar_area_1') ) : 
			dynamic_sidebar('sidebar_area_1');
		endif;
	?>
</aside>