<nav class="nav">
	<?php 
		wp_nav_menu(array(
			'theme_location' => 'header_nav',
		)); 
	?>
</nav>