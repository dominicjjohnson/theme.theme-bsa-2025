<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Call To Action', 'fw' ),
	'description' => __( 'Add a Call to Action', 'fw' ),
	'tab'         => __( 'Content Elements', 'fw' )
);