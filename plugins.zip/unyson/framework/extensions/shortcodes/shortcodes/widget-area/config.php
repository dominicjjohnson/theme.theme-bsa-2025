<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Widget Area', 'fw' ),
	'description' => __( 'Add a Widget Area', 'fw' ),
	'tab'         => __( 'Content Elements', 'fw' ),
);
