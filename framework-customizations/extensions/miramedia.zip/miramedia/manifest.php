<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name']         = __( 'Miramedia', 'fw' );
$manifest['version']      = '0.1';
$manifest['display']      = false;
$manifest['standalone']   = false;

//$manifest['github_update'] = 'ThemeFuse/Unyson-Shortcodes-Extension';
