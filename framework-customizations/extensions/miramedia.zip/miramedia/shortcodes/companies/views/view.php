<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

	$companies = array(
		array( 'name' => '#', 'image' => '1.png'),
		array( 'name' => '#', 'image' => '2.png'),
		array( 'name' => '#', 'image' => '3.png'),
		array( 'name' => '#', 'image' => '4.png'),
		array( 'name' => '#', 'image' => '5.png'),
		array( 'name' => '#', 'image' => '6.png'),
		array( 'name' => '#', 'image' => '7.png'),
		array( 'name' => '#', 'image' => '8.png'),
		array( 'name' => '#', 'image' => '9.png'),
		array( 'name' => '#', 'image' => '10.png'),
		array( 'name' => '#', 'image' => '11.png'),
		array( 'name' => '#', 'image' => '12.png'),
		array( 'name' => '#', 'image' => '13.png'),
		array( 'name' => '#', 'image' => '14.png'),
		array( 'name' => '#', 'image' => '15.png'),
		array( 'name' => '#', 'image' => '16.png'),
		array( 'name' => '#', 'image' => '17.png'),
		array( 'name' => '#', 'image' => '18.png'),
		array( 'name' => '#', 'image' => '19.png'),
		array( 'name' => '#', 'image' => '20.png'),
		array( 'name' => '#', 'image' => '21.png'),
		array( 'name' => '#', 'image' => '22.png'),
		array( 'name' => '#', 'image' => '23.png'),
		array( 'name' => '#', 'image' => '24.png'),
	);

	$companies = array_merge($companies, array_reverse($companies));

	$asseturi = get_stylesheet_directory_uri().'/assets/_content/company/'; ?>

	<section class="companies companies--wall">

	<?php foreach($companies as $company) : ?>

		<article class="company__excerpt company__excerpt--wall company__excerpt--wall">
			<div class="company__content">
				<div class="vert">
					<a href="" title="">
						<img src="<?php echo $asseturi . $company['image']; ?>" alt=""/>
					</a>
				</div>
			</div>
		</article>

	<?php endforeach; ?>

	</section>

<?php 