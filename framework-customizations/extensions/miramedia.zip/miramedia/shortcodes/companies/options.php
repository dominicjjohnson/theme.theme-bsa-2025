<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'example_block' => array(
		'type'     => 'multi-picker',
		'label'    => false,
		'desc'     => false,
		'picker' => array(
			'example_option' => array(
				'type'    => 'select',
				'label'   => __( 'Example option', 'fw' ),
				'desc'    => __( 'Here you can set an example option', 'fw' ),
				'choices' => array(
					'Option 1' => __( 'Option 1', 'fw' ),
					'Option 2' => __( 'Option 2', 'fw' ),
				)
			)
		),
	)
);
